This is an open-source project following the LinkedIn course, Create an Open-Source Project in Python

The main file for this project is tests.py, where I leanred how to set up some unit tests for the main program, reminder.py.  Additional files include support for black, flake8, and tox.
